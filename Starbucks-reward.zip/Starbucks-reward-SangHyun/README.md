## Starbucks-reward
[Original starbucks website](https://www.starbucks.com/)

### Page detail
* Header and footer
* Rewards 
* Gift Cards
* Menu  
 
#### We only cloned the **menu, rewards, giftcards** three pages. 
---
